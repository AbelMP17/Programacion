package clase.Framework;

import bpc.daw.consola.*;

public abstract class GameObject implements ElementoJuego{
    protected Juego juego;
    protected Consola consola;
    protected Escena escena;
}
