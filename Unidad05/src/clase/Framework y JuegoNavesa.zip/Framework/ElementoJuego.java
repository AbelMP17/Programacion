package clase.Framework;
public interface ElementoJuego {
    public void inicializar();
    public void ejecutarFrame();
    public void finalizar();
}
